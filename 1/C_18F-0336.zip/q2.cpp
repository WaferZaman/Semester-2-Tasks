	/*#include<iostream>
	#include<iomanip>
	#include<string.h>
	#include<windows.h>
	using namespace std;
	int main()
	{
		int arr[5];
		int sum=0;
		cout<<"Enter the Array entries :\n";
		for(int i=0;i<5;i++)
		{
			cout<<"Enter the Entry at ARRAY ["<<i<<"] index = ";
			cin>>arr[i];
		}
		int *ptr=arr;
		for(int i=0;i<5;i++)
		{
			sum+=*(ptr+i);
		}
		cout<<"\n      The sum of All the entries is :"<<sum;
		system("pause>0");
	}
	*/