/*#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int *arr=new int[10];
		for(int j=0;j<10;j++)
		{
			cout<<"arr ["<<j<<"] = ";
			cin>>arr[j];
		}
		double sum=0;
		double avg=0;
		for(int j=0;j<10;j++)
		{
			sum+=arr[j];
		}
		avg=sum/10;
		cout<<"\nThe sum of the array elemwnt is "<<sum;
		cout<<"\n The avergae of the 10 number is :"<<avg;
		
		

	system("pause>0");
}
*/